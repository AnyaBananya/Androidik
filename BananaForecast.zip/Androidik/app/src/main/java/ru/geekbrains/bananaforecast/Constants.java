package ru.geekbrains.bananaforecast;

public class Constants {
    public static final String EXTRA_PARCEL = "parcel";
    public static final String EXTRA_CURRENT_CITY = "CurrentCity";
}
