package ru.geekbrains.bananaforecast.observer;

public interface PublisherGetter {
    Publisher getPublisher();
}
