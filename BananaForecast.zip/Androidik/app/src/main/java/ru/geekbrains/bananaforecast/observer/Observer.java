package ru.geekbrains.bananaforecast.observer;

import ru.geekbrains.bananaforecast.City;

public interface Observer {
    void selectCity(City cityParcel);
}
